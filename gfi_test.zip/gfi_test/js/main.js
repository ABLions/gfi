class Grupo{
    constructor(id, arrayUsuario){
        this._id = id;
        this._arrayUsuario = arrayUsuario;
    }
} 

class Usuario{
    constructor(id, nombre, apellido){
        this._id = id;
        this._nombre = nombre;
        this._apellido = apellido;
    }
}

var myArray = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]; 
var nombres = ["Carlos", "Andres", "Maria", "Rocio", "Felipe", "Fernanda"];
var apellidos = ["Ruiz", "Martinez", "Florez", "Fernandez", "Dussan", "Ardila"];
var grupos = [1,2,3];

function crearGrupos(grupos){    
    var gruposCreados = [];
        grupos.forEach((el,i) => {
            var g = new Grupo(i,[]);
            gruposCreados.push(g); 
        });
    return gruposCreados;
}


function crearUsuarios(nuevosGrupos, myArray) {
    var usuariosCreados = [];
    myArray.forEach((el, i) => {
        var u = new Usuario(
            myArray, 
            nombres[random(0,nombres.length)], 
            apellidos[random(0,apellidos.length)]
        );
        usuariosCreados.push(u);      
    });
    return usuariosCreados       
}


function random(min, max){
     return Math.floor(min + Math.random() * (max - min));
}

var nuevosGrupos = crearGrupos(grupos);
var nuevosUsuarios = crearUsuarios(grupos, nuevosGrupos, myArray, random);
// console.log(grupos);
console.log(nuevosUsuarios);



